import type { NextConfig } from "next";

// Allow product photos stored in Supabase Storage (bucket: product-images) to go through next/image.
let supabaseHost: string | undefined;
try {
  supabaseHost = process.env.NEXT_PUBLIC_SUPABASE_URL ? new URL(process.env.NEXT_PUBLIC_SUPABASE_URL).hostname : undefined;
} catch {}

const nextConfig: NextConfig = {
  poweredByHeader: false,
  images: {
    remotePatterns: supabaseHost
      ? [{ protocol: "https", hostname: supabaseHost, pathname: "/storage/v1/object/public/**" }]
      : [],
  },
};
export default nextConfig;
