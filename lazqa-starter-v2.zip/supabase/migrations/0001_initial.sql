-- Lazqa initial schema. Run in Supabase SQL editor or through Supabase CLI.
create extension if not exists pgcrypto;

create type public.app_role as enum ('customer','company_owner','company_manager','company_member','admin','super_admin');
create type public.order_status as enum ('pending','confirmed','processing','shipped','delivered','cancelled');
create type public.payment_status as enum ('unpaid','pending','paid','failed','refunded','partially_refunded');

create table public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 full_name text,
 phone text,
 role public.app_role not null default 'customer',
 preferred_locale text not null default 'en' check (preferred_locale in ('en','ar')),
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);

create table public.orders (
 id uuid primary key default gen_random_uuid(),
 user_id uuid references auth.users(id) on delete set null,
 customer_name text not null check (char_length(customer_name) between 2 and 120),
 phone text not null,
 shipping_address text not null,
 status public.order_status not null default 'pending',
 payment_status public.payment_status not null default 'unpaid',
 payment_method text not null check (payment_method in ('cod','online')),
 currency char(3) not null default 'EGP',
 subtotal integer not null check (subtotal >= 0),
 shipping_fee integer not null default 0 check (shipping_fee >= 0),
 total integer not null check (total >= 0),
 items jsonb not null default '[]'::jsonb,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);
create index orders_user_created_idx on public.orders(user_id, created_at desc);

create table public.products (
 id uuid primary key default gen_random_uuid(),
 slug text not null unique,
 sku text unique,
 price integer not null check (price >= 0),
 currency char(3) not null default 'EGP',
 stock integer not null default 0 check (stock >= 0),
 active boolean not null default true,
 created_at timestamptz not null default now()
);
create table public.product_translations (
 product_id uuid not null references public.products(id) on delete cascade,
 locale text not null check (locale in ('en','ar')),
 name text not null,
 description text not null default '',
 primary key(product_id, locale)
);

create table public.payments (
 id uuid primary key default gen_random_uuid(),
 order_id uuid not null references public.orders(id) on delete restrict,
 provider text not null,
 provider_reference text unique,
 amount integer not null check (amount >= 0),
 currency char(3) not null default 'EGP',
 status public.payment_status not null default 'pending',
 idempotency_key text unique,
 provider_payload jsonb,
 created_at timestamptz not null default now()
);

create table public.qr_tags (
 id uuid primary key default gen_random_uuid(),
 token_hash text not null unique,
 product_code text,
 owner_user_id uuid references auth.users(id) on delete set null,
 label text,
 active boolean not null default true,
 created_at timestamptz not null default now()
);
create table public.qr_scan_events (
 id uuid primary key default gen_random_uuid(),
 qr_tag_id uuid not null references public.qr_tags(id) on delete cascade,
 scanned_at timestamptz not null default now(),
 user_agent text,
 -- Do not store precise IP addresses by default.
 metadata jsonb not null default '{}'::jsonb
);
create table public.recovery_messages (
 id uuid primary key default gen_random_uuid(),
 qr_tag_id uuid not null references public.qr_tags(id) on delete cascade,
 sender_name text,
 sender_message text not null check (char_length(sender_message) between 1 and 2000),
 sender_contact text,
 status text not null default 'new' check (status in ('new','read','closed','blocked')),
 created_at timestamptz not null default now()
);

create table public.referral_codes (
 id uuid primary key default gen_random_uuid(),
 owner_user_id uuid not null references auth.users(id) on delete cascade,
 code text not null unique,
 active boolean not null default true,
 created_at timestamptz not null default now()
);
create table public.referral_rewards (
 id uuid primary key default gen_random_uuid(),
 referral_code_id uuid not null references public.referral_codes(id) on delete restrict,
 referred_user_id uuid not null references auth.users(id) on delete cascade,
 order_id uuid references public.orders(id) on delete set null,
 reward_amount integer not null default 0 check (reward_amount >= 0),
 reward_type text not null default 'store_credit' check (reward_type in ('store_credit','cash_commission','discount')),
 status text not null default 'pending' check (status in ('pending','approved','paid','cancelled')),
 created_at timestamptz not null default now(),
 unique(referred_user_id)
);

create table public.companies (
 id uuid primary key default gen_random_uuid(),
 name text not null,
 tax_number text,
 status text not null default 'pending' check (status in ('pending','approved','suspended')),
 created_at timestamptz not null default now()
);
create table public.company_members (
 company_id uuid not null references public.companies(id) on delete cascade,
 user_id uuid not null references auth.users(id) on delete cascade,
 role public.app_role not null check (role in ('company_owner','company_manager','company_member')),
 created_at timestamptz not null default now(),
 primary key(company_id,user_id)
);
create table public.business_locations (
 id uuid primary key default gen_random_uuid(),
 company_id uuid not null references public.companies(id) on delete cascade,
 name text not null,
 address text,
 created_at timestamptz not null default now()
);
create table public.notifications (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade,
 title text not null,
 body text not null,
 read_at timestamptz,
 created_at timestamptz not null default now()
);
create table public.notification_preferences (
 user_id uuid primary key references auth.users(id) on delete cascade,
 email_enabled boolean not null default true,
 whatsapp_enabled boolean not null default false,
 in_app_enabled boolean not null default true
);
create table public.audit_logs (
 id uuid primary key default gen_random_uuid(),
 actor_user_id uuid references auth.users(id) on delete set null,
 action text not null,
 entity_type text not null,
 entity_id text,
 details jsonb not null default '{}'::jsonb,
 created_at timestamptz not null default now()
);

-- Secure by default: browser users cannot access tables until explicit policies are added.
alter table public.profiles enable row level security;
alter table public.orders enable row level security;
alter table public.products enable row level security;
alter table public.product_translations enable row level security;
alter table public.payments enable row level security;
alter table public.qr_tags enable row level security;
alter table public.qr_scan_events enable row level security;
alter table public.recovery_messages enable row level security;
alter table public.referral_codes enable row level security;
alter table public.referral_rewards enable row level security;
alter table public.companies enable row level security;
alter table public.company_members enable row level security;
alter table public.business_locations enable row level security;
alter table public.notifications enable row level security;
alter table public.notification_preferences enable row level security;
alter table public.audit_logs enable row level security;

-- Customers may read/update their own basic profile. Role changes must never be client-editable.
create policy "profile read own" on public.profiles for select to authenticated using (auth.uid() = id);
create policy "profile update own" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);
create policy "orders read own" on public.orders for select to authenticated using (auth.uid() = user_id);
create policy "notifications read own" on public.notifications for select to authenticated using (auth.uid() = user_id);
create policy "notification preferences own" on public.notification_preferences for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
-- Product catalog is intentionally public-read; writes are server/admin-only until explicit admin policies exist.
create policy "active products public read" on public.products for select to anon, authenticated using (active = true);
create policy "product translations public read" on public.product_translations for select to anon, authenticated using (
 exists (select 1 from public.products p where p.id = product_id and p.active = true)
);

-- Create a profile for new auth users. The role is always the fixed default customer.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = ''
as $$
begin
 insert into public.profiles (id, full_name)
 values (new.id, coalesce(new.raw_user_meta_data ->> 'full_name',''));
 return new;
end;
$$;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();