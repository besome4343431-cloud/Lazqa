-- Product images + longer product descriptions.
-- Run after 0001_initial.sql in the Supabase SQL editor.

alter table public.products add column if not exists image_url text;

alter table public.product_translations
  add column if not exists short_description text not null default '',
  add column if not exists long_description text not null default '';

-- Public bucket for product photos (anyone can view; only admins can upload/change).
insert into storage.buckets (id, name, public)
values ('product-images', 'product-images', true)
on conflict (id) do nothing;

create policy "product images public read"
  on storage.objects for select to anon, authenticated
  using (bucket_id = 'product-images');

create policy "product images admin insert"
  on storage.objects for insert to authenticated
  with check (bucket_id = 'product-images' and exists (
    select 1 from public.profiles p where p.id = auth.uid() and p.role in ('admin','super_admin')));

create policy "product images admin update"
  on storage.objects for update to authenticated
  using (bucket_id = 'product-images' and exists (
    select 1 from public.profiles p where p.id = auth.uid() and p.role in ('admin','super_admin')));

create policy "product images admin delete"
  on storage.objects for delete to authenticated
  using (bucket_id = 'product-images' and exists (
    select 1 from public.profiles p where p.id = auth.uid() and p.role in ('admin','super_admin')));

-- Test these policies with a normal user and an admin before launch.

-- SECURITY FIX: the "profile update own" policy in 0001 lets a signed-in user update ANY column of
-- their own profile, including `role` (e.g. promote themselves to admin). Restrict updates to safe columns.
revoke update on public.profiles from authenticated;
grant update (full_name, phone, preferred_locale, updated_at) on public.profiles to authenticated;
