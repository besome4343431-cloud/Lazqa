# Lazqa — starter implementation

A Next.js + TypeScript + Supabase foundation for the Lazqa store. It includes a responsive storefront, product catalogue, checkout request endpoint, account/admin status screens, and a starter relational schema.

## Important scope note

This is a **working foundation, not a finished production commerce platform**. Online payments, real QR-token issuance and recovery messaging, referral reward settlement, email/WhatsApp delivery, shipping-provider APIs, complete bilingual routes, and full admin CRUD are not enabled. The UI deliberately does not pretend these integrations have succeeded.

## Requirements

- Node.js 20.9+ (recommended)
- A Supabase project
- npm

## Run locally

1. Copy `.env.example` to `.env.local`.
2. Fill `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY`.
3. In Supabase SQL Editor, run `supabase/migrations/0001_initial.sql`.
4. Install and start:

   ```bash
   npm install
   npm run dev
   ```

5. Open http://localhost:3000.

Without Supabase environment values, the storefront still renders, but order submission will show a configuration message.

## Security notes before public launch

- Do not commit `.env.local`.
- Never put a Supabase service-role key, payment secret, or webhook secret in a `NEXT_PUBLIC_` variable.
- Do not put admin passwords in client-side JavaScript. Rotate any credential that was previously included in frontend code.
- Admin roles must be assigned by a trusted server-side process. Never allow users to set their own role.
- Online payment must use a provider checkout session and a verified signed webhook; never mark an order paid based only on a browser redirect.
- Before enabling QR tags, generate high-entropy random tokens server-side, store only a hash, rate-limit public message submission, add abuse controls, and avoid exposing the owner's phone number.
- Review and test Row Level Security policies before launch. The included schema starts locked down; add narrowly scoped policies as each feature is implemented.
- Prices in `src/lib/products.ts` are a demo catalogue. For production, use database-backed products and calculate prices exclusively on the server.
- Add CSRF/rate-limit protections, logging, backups, privacy/retention rules, and monitoring before production.

## What's new in this version

- **Images:** custom illustrations in `public/images/` (hero, one per product, 3 step icons, logo, placeholder), a favicon (`src/app/icon.svg`) and share images (`opengraph-image.png`, `twitter-image.png`) so links look right on WhatsApp/Facebook. All use `next/image` with proper `alt` text. The QR codes in the artwork are decorative and are **not scannable**.
- **Product pages:** `/products/[slug]` with full description, features, how-it-works, use cases and FAQ. `/la2etha` reuses the same content.
- **Arabic/English:** Arabic (RTL) is the default; the toggle in the nav stores a `lang` cookie. All copy lives in `src/lib/i18n.ts` and `src/lib/products.ts`; have the owner review the wording and confirm any claims before launch.
- **Supabase images:** `supabase/migrations/0002_product_images.sql` adds `image_url`, longer descriptions, a public `product-images` bucket with admin-only uploads, and fixes a privilege-escalation gap on `profiles.role` (run it!). `next.config.ts` already allows images from your Supabase host.
- **Orders API:** basic in-memory rate limit (replace with a shared store on serverless hosting) and error codes the UI translates.

## Main routes

- `/` — storefront
- `/la2etha` — La2etha explainer
- `/products/[slug]` — product detail page
- `/checkout?product=la2etha-tag` — checkout request
- `/account` — account session status
- `/admin` — protected-by-role status overview
- `POST /api/orders` — validated cash-on-delivery order request

## Next implementation stages

1. Supabase sign-up/sign-in/password reset UI and session middleware.
2. Database-backed product catalogue, inventory reservation, shipping calculations.
3. Payment-provider integration and verified webhook processing.
4. Unique QR issuance, public scan page, private owner inbox, abuse controls.
5. Referral attribution and idempotent rewards.
6. Company memberships, branches, B2B price lists and purchase workflows.
7. Admin CRUD, audit logs, notification providers, Arabic/English routes and tests.
