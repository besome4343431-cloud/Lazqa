import { createClient } from "@/lib/supabase/server";
import { getLang, tr } from "@/lib/i18n";
import SiteNav from "@/components/SiteNav";

export default async function Account() {
  const lang = await getLang();
  const t = tr(lang);
  let user = null;
  let error = false;
  try {
    const supabase = await createClient();
    const result = await supabase.auth.getUser();
    user = result.data.user;
  } catch {
    error = true;
  }
  return (
    <main className="container">
      <SiteNav lang={lang} path="/account" full={false} />
      <section>
        <div className="eyebrow">{t("acEyebrow")}</div>
        <h1 className="page-h1">{t("acTitle")}</h1>
        <div className="adminbox">
          {error ? (
            <p>{t("acNoDb")}</p>
          ) : user ? (
            <>
              <p>
                {t("acSignedIn")} <strong>{user.email}</strong>
              </p>
              <p>{t("acActive")}</p>
            </>
          ) : (
            <>
              <p>{t("acGuest")}</p>
              <p>{t("acNext")}</p>
            </>
          )}
        </div>
      </section>
    </main>
  );
}
