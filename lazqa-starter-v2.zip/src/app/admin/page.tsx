import { createClient } from "@/lib/supabase/server";
import { getLang, tr } from "@/lib/i18n";
import SiteNav from "@/components/SiteNav";

export default async function Admin() {
  const lang = await getLang();
  const t = tr(lang);
  let status = t("adNoDb");
  let count = "—";
  try {
    const db = await createClient();
    const {
      data: { user },
    } = await db.auth.getUser();
    if (!user) status = t("adSignIn");
    else {
      const { data: profile } = await db.from("profiles").select("role").eq("id", user.id).maybeSingle();
      if (profile?.role === "admin" || profile?.role === "super_admin") {
        status = t("adVerified");
        const { count: n } = await db.from("orders").select("*", { count: "exact", head: true });
        count = String(n ?? 0);
      } else status = t("adNoRole");
    }
  } catch {}
  return (
    <main className="container">
      <SiteNav lang={lang} path="/admin" full={false} />
      <section>
        <div className="eyebrow">{t("adEyebrow")}</div>
        <h1 className="page-h1">{t("adTitle")}</h1>
        <div className="adminbox">
          <p>
            <strong>{t("adStatus")}</strong> {status}
          </p>
          <p>
            <strong>{t("adOrders")}</strong> {count}
          </p>
          <p className="lead">{t("adNote")}</p>
        </div>
      </section>
    </main>
  );
}
