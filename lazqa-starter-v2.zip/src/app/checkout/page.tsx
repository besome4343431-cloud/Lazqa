import { Suspense } from "react";
import type { Metadata } from "next";
import { findProduct, products } from "@/lib/products";
import { getLang, tr, ui, type UiKey } from "@/lib/i18n";
import SiteNav from "@/components/SiteNav";
import CheckoutForm from "./CheckoutForm";

export async function generateMetadata(): Promise<Metadata> {
  return { title: tr(await getLang())("ckTitle") };
}

export default async function Checkout({ searchParams }: { searchParams: Promise<{ product?: string }> }) {
  const lang = await getLang();
  const t = tr(lang);
  const { product: slug } = await searchParams;
  const product = findProduct(slug) ?? products[0];

  const keys: UiKey[] = [
    "ckName", "ckPhone", "ckAddress", "ckQty", "ckPay", "ckCod", "ckOnline", "ckOnlineNotice", "ckTotal", "ckDelivery",
    "ckSubmit", "ckBusy", "ckSuccess", "ckSuccessNote", "ckEach", "ckErrInvalid", "ckErrNotFound", "ckErrOnline", "ckErrRate", "ckErrService",
  ];
  const strings = Object.fromEntries(keys.map((k) => [k, ui[k][lang]])) as Record<string, string>;

  return (
    <main className="container">
      <SiteNav lang={lang} path={`/checkout?product=${product.slug}`} full={false} />
      <section>
        <div className="eyebrow">{t("ckEyebrow")}</div>
        <h1 className="page-h1">{t("ckTitle")}</h1>
        <Suspense fallback={<p>{t("ckLoading")}</p>}>
          <CheckoutForm
            lang={lang}
            strings={strings}
            product={{ id: product.id, name: product.name[lang], price: product.price, image: product.image, imageAlt: product.imageAlt[lang] }}
          />
        </Suspense>
      </section>
    </main>
  );
}
