"use client";
import { useState } from "react";
import Image from "next/image";
import { formatEGP } from "@/lib/money";

type Props = {
  lang: "ar" | "en";
  strings: Record<string, string>;
  product: { id: string; name: string; price: number; image: string; imageAlt: string };
};

const errorKey: Record<string, string> = {
  invalid: "ckErrInvalid",
  not_found: "ckErrNotFound",
  online_unavailable: "ckErrOnline",
  rate_limited: "ckErrRate",
  service: "ckErrService",
};

export default function CheckoutForm({ lang, strings: s, product }: Props) {
  const locale = lang === "ar" ? "ar-EG" : "en-EG";
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [qty, setQty] = useState(1);
  const [method, setMethod] = useState("cod");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setMessage("");
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ productId: product.id, quantity: qty, customerName: name, phone, address, paymentMethod: method }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(s[errorKey[data.code] ?? "ckErrService"]);
      setMessage(`${s.ckSuccess} ${data.orderId}. ${s.ckSuccessNote}`);
    } catch (err) {
      setMessage(err instanceof Error ? err.message : s.ckErrService);
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <div className="summary">
        <Image src={product.image} alt={product.imageAlt} width={160} height={120} unoptimized={product.image.endsWith(".svg")} />
        <div>
          <strong>{product.name}</strong>
          <div className="lead" style={{ margin: 0 }}>
            {formatEGP(product.price, locale)} {s.ckEach}
          </div>
        </div>
      </div>
      <form className="form" onSubmit={submit}>
        <label>
          {s.ckName}
          <input required minLength={2} value={name} onChange={(e) => setName(e.target.value)} autoComplete="name" />
        </label>
        <label>
          {s.ckPhone}
          <input required minLength={8} value={phone} onChange={(e) => setPhone(e.target.value)} autoComplete="tel" inputMode="tel" dir="ltr" />
        </label>
        <label>
          {s.ckAddress}
          <input required minLength={8} value={address} onChange={(e) => setAddress(e.target.value)} autoComplete="street-address" />
        </label>
        <label>
          {s.ckQty}
          <input type="number" min={1} max={20} required value={qty} onChange={(e) => setQty(Math.max(1, Math.min(20, Number(e.target.value))))} />
        </label>
        <label>
          {s.ckPay}
          <select value={method} onChange={(e) => setMethod(e.target.value)}>
            <option value="cod">{s.ckCod}</option>
            <option value="online">{s.ckOnline}</option>
          </select>
        </label>
        {method === "online" && <div className="notice">{s.ckOnlineNotice}</div>}
        <div className="notice">
          {s.ckTotal} <strong>{formatEGP(product.price * qty, locale)}</strong>. {s.ckDelivery}
        </div>
        <button className="btn primary" disabled={busy || method === "online"}>
          {busy ? s.ckBusy : s.ckSubmit}
        </button>
        {message && (
          <div className="status" role="status">
            {message}
          </div>
        )}
      </form>
    </>
  );
}
