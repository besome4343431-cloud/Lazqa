import type { Metadata } from "next";
import "./globals.css";
import { getLang, tr } from "@/lib/i18n";

export async function generateMetadata(): Promise<Metadata> {
  const lang = await getLang();
  const description = tr(lang)("siteDesc");
  return {
    metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000"),
    title: { default: "Lazqa | لزقة", template: "%s | Lazqa" },
    description,
    openGraph: { title: "Lazqa | لزقة", description, type: "website", siteName: "Lazqa", locale: lang === "ar" ? "ar_EG" : "en_US" },
    twitter: { card: "summary_large_image", title: "Lazqa | لزقة", description },
  };
}

export default async function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  const lang = await getLang();
  return (
    <html lang={lang} dir={lang === "ar" ? "rtl" : "ltr"}>
      <body>{children}</body>
    </html>
  );
}
