import { NextResponse } from "next/server";

export function GET(request: Request) {
  const url = new URL(request.url);
  const set = url.searchParams.get("set");
  let next = url.searchParams.get("next") ?? "/";
  // Only allow same-site relative paths to avoid open redirects.
  if (!next.startsWith("/") || next.startsWith("//") || next.includes("\\")) next = "/";
  const res = NextResponse.redirect(new URL(next, url.origin), 303);
  if (set === "ar" || set === "en") {
    res.cookies.set("lang", set, { path: "/", maxAge: 60 * 60 * 24 * 365, sameSite: "lax" });
  }
  return res;
}
