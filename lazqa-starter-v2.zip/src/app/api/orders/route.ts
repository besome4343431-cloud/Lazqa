import { NextResponse } from "next/server";
import { z } from "zod";
import { products } from "@/lib/products";
import { createClient } from "@/lib/supabase/server";
import { rateLimit } from "@/lib/rateLimit";

const OrderInput = z.object({
  productId: z.string().min(1),
  quantity: z.number().int().min(1).max(20),
  customerName: z.string().trim().min(2).max(120),
  phone: z.string().trim().min(8).max(25),
  address: z.string().trim().min(8).max(500),
  paymentMethod: z.enum(["cod", "online"]),
});

// Error responses carry a stable `code` so the UI can show a message in the visitor's language.
const fail = (code: string, error: string, status: number) => NextResponse.json({ code, error }, { status });

export async function POST(request: Request) {
  const ip = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "unknown";
  if (!rateLimit(`orders:${ip}`)) return fail("rate_limited", "Too many requests. Try again later.", 429);

  const parsed = OrderInput.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return fail("invalid", "Please check the order details.", 400);
  const input = parsed.data;

  // Price always comes from the server-side catalogue, never from the browser.
  const product = products.find((p) => p.id === input.productId);
  if (!product) return fail("not_found", "Product not found.", 404);
  if (input.paymentMethod === "online") return fail("online_unavailable", "Online payment is not configured yet.", 501);

  try {
    const supabase = await createClient();
    const {
      data: { user },
    } = await supabase.auth.getUser();
    const total = product.price * input.quantity;
    const { data, error } = await supabase
      .from("orders")
      .insert({
        user_id: user?.id ?? null,
        customer_name: input.customerName,
        phone: input.phone,
        shipping_address: input.address,
        status: "pending",
        payment_status: "unpaid",
        payment_method: "cod",
        currency: "EGP",
        subtotal: total,
        total,
        items: [{ product_id: product.id, name: product.name.en, unit_price: product.price, quantity: input.quantity }],
      })
      .select("id")
      .single();
    if (error) {
      console.error("Order insert failed:", error.message);
      return fail("service", "Order service is not ready.", 503);
    }
    return NextResponse.json({ orderId: data.id }, { status: 201 });
  } catch {
    return fail("service", "Order service is not configured.", 503);
  }
}
