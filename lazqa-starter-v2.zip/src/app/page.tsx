import Link from "next/link";
import Image from "next/image";
import { products } from "@/lib/products";
import { formatEGP } from "@/lib/money";
import { getLang, tr } from "@/lib/i18n";
import SiteNav from "@/components/SiteNav";
import SiteFooter from "@/components/SiteFooter";
import ProductImage from "@/components/ProductImage";

export default async function Home() {
  const lang = await getLang();
  const t = tr(lang);
  const locale = lang === "ar" ? "ar-EG" : "en-EG";
  const steps = products[0].steps;
  return (
    <main>
      <div className="container">
        <SiteNav lang={lang} path="/" />
        <section className="hero">
          <div>
            <div className="eyebrow">{t("heroEyebrow")}</div>
            <h1>
              {t("heroLine1")}
              <br />
              <span>{t("heroLine2")}</span>
            </h1>
            <p className="lead">{t("heroLead")}</p>
            <div className="actions">
              <a className="btn primary" href="#products">
                {t("heroCta1")}
              </a>
              <Link className="btn secondary" href="/la2etha">
                {t("heroCta2")}
              </Link>
            </div>
          </div>
          <div className="hero-card">
            <span className="pill">{t("heroPill")}</span>
            <Image className="hero-img" src="/images/hero.svg" alt={t("heroAlt")} width={900} height={720} priority unoptimized />
            <div>
              <h2>{t("heroCardTitle")}</h2>
              <small>{t("heroCardSub")}</small>
            </div>
          </div>
        </section>

        <section id="products">
          <div className="section-head">
            <div>
              <h2>{t("productsTitle")}</h2>
              <p>{t("productsSub")}</p>
            </div>
            <span className="pill">{t("shopPill")}</span>
          </div>
          <div className="grid">
            {products.map((p, i) => (
              <article className="product" key={p.id}>
                <Link href={`/products/${p.slug}`} className="product-media" aria-label={p.name[lang]}>
                  <ProductImage src={p.image} alt={p.imageAlt[lang]} priority={i === 0} />
                </Link>
                <span className="pill">{p.category[lang]}</span>
                <h3>{p.name[lang]}</h3>
                <p>{p.short[lang]}</p>
                <ul className="ticks">
                  {p.highlights.map((h, j) => (
                    <li key={j}>{h[lang]}</li>
                  ))}
                </ul>
                <div className="card-actions">
                  <span className="price">{formatEGP(p.price, locale)}</span>
                  <div className="btns">
                    <Link className="btn secondary" href={`/products/${p.slug}`}>
                      {t("details")}
                    </Link>
                    <Link className="btn primary" href={`/checkout?product=${p.slug}`}>
                      {t("order")}
                    </Link>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section>
          <div className="section-head">
            <div>
              <h2>{t("howTitle")}</h2>
              <p>{t("howSub")}</p>
            </div>
          </div>
          <div className="steps">
            {steps.map((s, i) => (
              <div className="step" key={i}>
                <Image src={s.image} alt="" width={240} height={240} unoptimized />
                <div className="num">
                  {t("step")} {lang === "ar" ? ["١", "٢", "٣"][i] : i + 1}
                </div>
                <h3>{s.title[lang]}</h3>
                <p>{s.text[lang]}</p>
              </div>
            ))}
          </div>
        </section>

        <section>
          <div className="notice">
            <strong>{t("homeNoticeTitle")}</strong> {t("homeNotice")}
          </div>
        </section>
        <SiteFooter lang={lang} />
      </div>
    </main>
  );
}
