import Link from "next/link";
import type { Metadata } from "next";
import { findProduct } from "@/lib/products";
import { getLang, tr } from "@/lib/i18n";
import SiteNav from "@/components/SiteNav";
import SiteFooter from "@/components/SiteFooter";
import ProductImage from "@/components/ProductImage";
import ProductSections from "@/components/ProductSections";

export async function generateMetadata(): Promise<Metadata> {
  const lang = await getLang();
  return { title: tr(lang)("navLa2etha"), description: tr(lang)("laLead") };
}

export default async function La2etha() {
  const lang = await getLang();
  const t = tr(lang);
  const product = findProduct("la2etha-tag")!;
  return (
    <main className="container">
      <SiteNav lang={lang} path="/la2etha" />
      <section className="hero">
        <div>
          <div className="eyebrow">{t("laEyebrow")}</div>
          <h1 className="page-h1">{t("laTitle")}</h1>
          <p className="lead">{t("laLead")}</p>
          <div className="actions">
            <Link className="btn primary" href="/checkout?product=la2etha-tag">
              {t("laCta1")}
            </Link>
            <Link className="btn secondary" href="/#products">
              {t("laCta2")}
            </Link>
          </div>
        </div>
        <div className="pd-media">
          <ProductImage src={product.image} alt={product.imageAlt[lang]} priority sizes="(max-width: 760px) 100vw, 480px" className="pd-img" />
        </div>
      </section>
      <section>
        <div className="notice">{t("laDemo")}</div>
      </section>
      <ProductSections product={product} lang={lang} />
      <SiteFooter lang={lang} />
    </main>
  );
}
