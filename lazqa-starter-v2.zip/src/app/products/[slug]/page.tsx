import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { findProduct, products } from "@/lib/products";
import { formatEGP } from "@/lib/money";
import { getLang, tr } from "@/lib/i18n";
import SiteNav from "@/components/SiteNav";
import SiteFooter from "@/components/SiteFooter";
import ProductImage from "@/components/ProductImage";
import ProductSections from "@/components/ProductSections";

type Props = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const product = findProduct((await params).slug);
  if (!product) return {};
  const lang = await getLang();
  return { title: product.name[lang], description: product.short[lang], openGraph: { images: [product.image] } };
}

export default async function ProductPage({ params }: Props) {
  const { slug } = await params;
  const product = findProduct(slug);
  if (!product) notFound();
  const lang = await getLang();
  const t = tr(lang);
  const locale = lang === "ar" ? "ar-EG" : "en-EG";
  const isTag = product.category.en === "QR Tags";
  const others = products.filter((p) => p.slug !== product.slug);

  return (
    <main className="container">
      <SiteNav lang={lang} path={`/products/${product.slug}`} />
      <section>
        <div className="pd">
          <div className="pd-media">
            <ProductImage src={product.image} alt={product.imageAlt[lang]} priority sizes="(max-width: 760px) 100vw, 540px" className="pd-img" />
          </div>
          <div>
            <span className="pill">{product.category[lang]}</span>
            <h1>{product.name[lang]}</h1>
            <p className="lead">{product.short[lang]}</p>
            <div className="pricebox">
              <span className="price">{formatEGP(product.price, locale)}</span>
              <small>{t("pdEach")}</small>
            </div>
            <ul className="ticks">
              {product.highlights.map((h, i) => (
                <li key={i}>{h[lang]}</li>
              ))}
            </ul>
            <div className="actions">
              <Link className="btn primary" href={`/checkout?product=${product.slug}`}>
                {t("orderNow")}
              </Link>
              <Link className="btn secondary" href="/#products">
                {t("backToProducts")}
              </Link>
            </div>
            <div className="desc">
              {product.description.map((d, i) => (
                <p key={i}>{d[lang]}</p>
              ))}
            </div>
          </div>
        </div>
      </section>

      <ProductSections product={product} lang={lang} />

      {isTag && (
        <section>
          <div className="notice">{t("pdDemo")}</div>
        </section>
      )}

      <section>
        <h2 className="subhead">{t("pdMore")}</h2>
        <div className="grid">
          {others.map((p) => (
            <article className="product" key={p.id}>
              <Link href={`/products/${p.slug}`} className="product-media" aria-label={p.name[lang]}>
                <ProductImage src={p.image} alt={p.imageAlt[lang]} />
              </Link>
              <span className="pill">{p.category[lang]}</span>
              <h3>{p.name[lang]}</h3>
              <p>{p.short[lang]}</p>
              <div className="card-actions">
                <span className="price">{formatEGP(p.price, locale)}</span>
                <Link className="btn secondary" href={`/products/${p.slug}`}>
                  {t("details")}
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>
      <SiteFooter lang={lang} />
    </main>
  );
}
