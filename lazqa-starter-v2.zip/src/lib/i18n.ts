import { cookies } from "next/headers";

export type Lang = "ar" | "en";
export type L = { ar: string; en: string };

export async function getLang(): Promise<Lang> {
  const v = (await cookies()).get("lang")?.value;
  return v === "en" ? "en" : "ar";
}

export const ui = {
  navProducts: { ar: "المنتجات", en: "Products" },
  navLa2etha: { ar: "لاقيتها QR", en: "La2etha QR" },
  navAccount: { ar: "حسابي", en: "Account" },
  navAdmin: { ar: "الإدارة", en: "Admin" },
  navStore: { ar: "المتجر", en: "Store" },
  backToStore: { ar: "العودة للمتجر", en: "Back to store" },
  backToProducts: { ar: "كل المنتجات", en: "All products" },
  home: { ar: "الرئيسية", en: "Home" },
  siteDesc: { ar: "تاجات QR ذكية وأدوات للبيزنس من لزقة.", en: "Smart QR tags and business tools by Lazqa." },

  heroEyebrow: { ar: "أدوات يومية أذكى", en: "SMARTER EVERYDAY ESSENTIALS" },
  heroLine1: { ar: "حاجتك هترجعلك.", en: "Lost less." },
  heroLine2: { ar: "وبالك هيرتاح.", en: "Live more." },
  heroLead: {
    ar: "منتجات بسيطة بتشتغل برمز QR وبتساعد الناس ترجّع حاجتها لو ضاعت، وأدوات ذكية تساعد البيزنس يكبر.",
    en: "Simple QR-powered products that help people reconnect with their belongings, plus smart tools for growing businesses.",
  },
  heroCta1: { ar: "استكشف المنتجات", en: "Explore products" },
  heroCta2: { ar: "إزاي لاقيتها بتشتغل", en: "How La2etha works" },
  heroPill: { ar: "لاقيتها · تاج QR", en: "LA2ETHA · QR TAG" },
  heroCardTitle: { ar: "حاجتك ليها طريق أذكى للرجوع.", en: "Your things. A smarter way back." },
  heroCardSub: { ar: "امسح · ابعت رسالة · استلم حاجتك", en: "Scan · Send a message · Reconnect" },
  heroAlt: {
    ar: "تاج QR بيتمسح بموبايل وبتوصل رسالة لصاحبه",
    en: "A QR tag being scanned by a phone, sending a message to the owner",
  },

  productsTitle: { ar: "اتعمل عشان يفيدك.", en: "Made to be useful." },
  productsSub: { ar: "تعرّف على منتجات لزقة الحالية واقرأ تفاصيل كل منتج.", en: "Explore the current Lazqa range and read the details of each product." },
  shopPill: { ar: "المتجر · جنيه مصري", en: "SHOP · EGP" },
  order: { ar: "اطلب", en: "Order" },
  orderNow: { ar: "اطلب دلوقتي", en: "Order now" },
  details: { ar: "التفاصيل", en: "Details" },

  howTitle: { ar: "إزاي بتشتغل؟", en: "How does it work?" },
  howSub: { ar: "ثلاث خطوات بسيطة من غير تطبيقات ولا تعقيد.", en: "Three simple steps. No apps, no fuss." },
  step: { ar: "خطوة", en: "STEP" },

  homeNoticeTitle: { ar: "طريقة الطلب في النسخة الحالية:", en: "How ordering works in this starter version:" },
  homeNotice: {
    ar: "نموذج الطلب بيجمع بياناتك ويحفظها في قاعدة البيانات لما تكون متفعّلة، والدفع حالياً عند الاستلام. الدفع الأونلاين مش مفعّل لسه، ومش هنعرض إنه شغال قبل ما يتربط بمزوّد دفع ويتأكد بتوقيع آمن.",
    en: "The checkout form collects order details and saves them to Supabase when configured. Payment provider integration is intentionally not simulated; enable a provider and verify its signed webhook before accepting online payments.",
  },
  footer: { ar: "لزقة. اتعملت لحياة يومية أأمن وأذكى.", en: "Lazqa. Built for a safer, smarter everyday." },

  // product page
  pdPrice: { ar: "السعر", en: "Price" },
  pdEach: { ar: "للقطعة", en: "each" },
  pdFeatures: { ar: "مميزات المنتج", en: "Key features" },
  pdHow: { ar: "إزاي بيشتغل", en: "How it works" },
  pdIdeal: { ar: "مناسب لـ", en: "Perfect for" },
  pdFaq: { ar: "أسئلة شائعة", en: "Frequently asked questions" },
  pdMore: { ar: "منتجات تانية ممكن تعجبك", en: "You might also like" },
  pdDemo: {
    ar: "ملحوظة: صفحة المسح العامة وصندوق رسائل المالك لسه قيد التفعيل. متطبعش أي أكواد QR حقيقية قبل ما التوكنات العشوائية وضوابط الخصوصية تتفعّل وتتجرّب.",
    en: "Note: the public scan page and the owner's private inbox are still being enabled. Do not print production QR codes until random tokens and privacy controls are deployed and tested.",
  },

  // la2etha page
  laEyebrow: { ar: "لاقيتها QR", en: "LA2ETHA QR" },
  laTitle: { ar: "ساعد حاجتك الضايعة ترجعلك.", en: "Help your lost item find its way back." },
  laLead: {
    ar: "ركّب تاج QR على شنطة أو مفاتيح أو أي حاجة شخصية. لو حد لقاها يمسح الرمز ويبعتلك رسالة، من غير ما يشوف رقم تليفونك بشكل افتراضي.",
    en: "Attach a QR tag to a bag, keychain, or personal item. If someone finds it, they can scan the tag and send a message without seeing your phone number by default.",
  },
  laCta1: { ar: "اطلب تاج لاقيتها", en: "Get a La2etha Tag" },
  laCta2: { ar: "تصفّح المنتجات", en: "Browse products" },
  laDemo: {
    ar: "معلومة تجريبية: التاج الحقيقي محتاج توكن عشوائي فريد محفوظ في قاعدة البيانات. متطبعش أكواد حقيقية قبل ما إنشاء التوكنات وضوابط الخصوصية وصفحة المسح العامة تتفعّل وتتجرّب.",
    en: "Demo information: a real tag needs a unique random token stored in the database. Do not print production QR codes until token creation, privacy controls, and the public scan page are deployed and tested.",
  },

  // checkout
  ckEyebrow: { ar: "إتمام الطلب", en: "CHECKOUT" },
  ckTitle: { ar: "اطلب منتجك.", en: "Place your order." },
  ckEach: { ar: "للقطعة", en: "each" },
  ckName: { ar: "الاسم بالكامل", en: "Full name" },
  ckPhone: { ar: "رقم التليفون", en: "Phone number" },
  ckAddress: { ar: "عنوان التوصيل", en: "Delivery address" },
  ckQty: { ar: "الكمية (لحد ٢٠ في الطلب)", en: "Quantity (up to 20 per order)" },
  ckPay: { ar: "طريقة الدفع", en: "Payment method" },
  ckCod: { ar: "الدفع عند الاستلام", en: "Cash on delivery" },
  ckOnline: { ar: "دفع أونلاين (مش متاح لحد ما يتفعّل مزوّد الدفع)", en: "Online payment (not enabled until provider setup)" },
  ckOnlineNotice: { ar: "الدفع الأونلاين مش شغال في النسخة دي، ومفيش بيانات كارت بتتجمع هنا.", en: "Online payment is not active in this starter. No card details are collected here." },
  ckTotal: { ar: "إجمالي المنتجات التقريبي:", en: "Estimated product total:" },
  ckDelivery: { ar: "مصاريف الشحن بتتأكد من المتجر، وهنتصل بيك لتأكيد الطلب.", en: "Delivery fees are confirmed by the store." },
  ckSubmit: { ar: "ابعت طلب الشراء", en: "Submit order request" },
  ckBusy: { ar: "جاري الإرسال…", en: "Submitting…" },
  ckSuccess: { ar: "تم تسجيل طلبك برقم:", en: "Order request created:" },
  ckSuccessNote: { ar: "ده مش تأكيد دفع أونلاين.", en: "This is not an online payment confirmation." },
  ckErrInvalid: { ar: "راجع بيانات الطلب من فضلك.", en: "Please check the order details." },
  ckErrNotFound: { ar: "المنتج مش موجود.", en: "Product not found." },
  ckErrOnline: { ar: "الدفع الأونلاين مش متاح لسه.", en: "Online payment is not configured yet." },
  ckErrRate: { ar: "طلبات كتير في وقت قصير. جرّب تاني بعد شوية.", en: "Too many requests. Please try again in a few minutes." },
  ckErrService: { ar: "خدمة الطلبات مش جاهزة. جهّز قاعدة البيانات وجرّب تاني.", en: "Order service is not ready. Configure the database and try again." },
  ckLoading: { ar: "جاري تحميل صفحة الطلب…", en: "Loading checkout…" },

  // account / admin
  acEyebrow: { ar: "حسابك", en: "YOUR ACCOUNT" },
  acTitle: { ar: "الحساب", en: "Account" },
  acNoDb: { ar: "Supabase لسه مش متظبط. أضف مفاتيحك في ملف .env.local لتفعيل جلسات الحساب.", en: "Supabase is not configured yet. Add your Supabase keys to .env.local to enable account sessions." },
  acSignedIn: { ar: "مسجّل دخول بـ", en: "Signed in as" },
  acActive: { ar: "جلسة حسابك شغّالة.", en: "Your account session is active." },
  acGuest: { ar: "انت بتتصفح كزائر.", en: "You are browsing as a guest." },
  acNext: { ar: "شاشات تسجيل الدخول هي الخطوة الجاية؛ استخدم Supabase Auth لتسجيل وتسجيل دخول واستعادة كلمة مرور آمنة.", en: "Authentication screens are the next setup step; use Supabase Auth for secure sign-up, sign-in, and password reset." },
  adEyebrow: { ar: "مركز التحكم", en: "CONTROL CENTER" },
  adTitle: { ar: "نظرة عامة للإدارة", en: "Admin overview" },
  adStatus: { ar: "الحالة:", en: "Status:" },
  adOrders: { ar: "الطلبات:", en: "Orders:" },
  adNoDb: { ar: "قاعدة البيانات مش متظبطة.", en: "Database not configured." },
  adSignIn: { ar: "لازم تسجّل دخول. صلاحية الإدارة بتتعيّن من مسؤول موثوق.", en: "Sign in required. Admin access must be assigned by a trusted administrator." },
  adVerified: { ar: "تم التحقق من صلاحية الإدارة.", en: "Admin role verified." },
  adNoRole: { ar: "حسابك ملوش صلاحية إدارة.", en: "Your account does not have an administrator role." },
  adNote: { ar: "النسخة دي مش بتعرض بيانات العملاء ولا بتوفر إجراءات إدارية لحد ما سياسات الصلاحيات على السيرفر تتظبط.", en: "This starter intentionally does not expose customer data or provide admin actions until server-side role policies are configured." },
} satisfies Record<string, L>;

export type UiKey = keyof typeof ui;
export const tr = (lang: Lang) => (key: UiKey) => ui[key][lang];
