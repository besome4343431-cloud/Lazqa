import type { L } from "./i18n";

export type Product = {
  id: string;
  slug: string;
  price: number;
  currency: "EGP";
  category: L;
  image: string; // local path, or a Supabase Storage URL once products move to the database
  imageAlt: L;
  name: L;
  short: L;
  description: L[];
  highlights: L[];
  features: { title: L; text: L }[];
  steps: { title: L; text: L; image: string }[];
  idealFor: L[];
  faq: { q: L; a: L }[];
};

const stepImgs = ["/images/step-attach.svg", "/images/step-scan.svg", "/images/step-message.svg"];

// Demo catalogue. Prices here are for display only; the server re-reads them from this list
// when creating orders. Move to database-backed products before production.
export const products: Product[] = [
  {
    id: "la2etha-tag",
    slug: "la2etha-tag",
    price: 150,
    currency: "EGP",
    category: { ar: "تاجات QR", en: "QR Tags" },
    image: "/images/la2etha-tag.svg",
    imageAlt: {
      ar: "تاج لاقيتها QR متعلّق في حلقة مفاتيح مع فقاعة رسالة ودرع خصوصية",
      en: "La2etha QR tag on a key ring with a message bubble and a privacy shield",
    },
    name: { ar: "لاقيتها – تاج QR", en: "La2etha Tag" },
    short: {
      ar: "تاج QR صغير تعلّقه على حاجتك، ولو ضاعت اللي يلاقيها يبعتلك رسالة من غير ما يشوف رقمك.",
      en: "A small QR tag for your belongings. If something goes missing, the finder can message you without ever seeing your number.",
    },
    description: [
      {
        ar: "كلنا ضيّعنا حاجة مهمة مرة: مفاتيح، شنطة، شاحن أو حتى سماعات. «لاقيتها» بتحل المشكلة دي ببساطة: تاج بيحمل رمز QR فريد مربوط بحسابك.",
        en: "We have all lost something important at least once: keys, a bag, a charger, even earbuds. La2etha solves it simply: a tag carrying a unique QR code linked to your account.",
      },
      {
        ar: "اللي يلاقي حاجتك يمسح الرمز بكاميرا موبايله ويكتبلك رسالة، وانت بتوصلك الرسالة وتتفقوا على التسليم. رقم تليفونك بيفضل مخفي بشكل افتراضي، فمش لازم تشارك بياناتك الشخصية مع حد غريب.",
        en: "Whoever finds your item scans the code with their phone camera and writes you a message; you receive it and arrange the hand-over. Your phone number stays hidden by default, so you never have to share personal details with a stranger.",
      },
      {
        ar: "التاج مناسب لأي حاجة بتتحرك معاك كل يوم، وبيتركّب في ثواني من غير أي جهاز أو بطارية أو شحن.",
        en: "The tag suits anything that travels with you every day, and it goes on in seconds with no device, battery, or charging.",
      },
    ],
    highlights: [
      { ar: "رمز QR فريد لكل تاج", en: "A unique QR code on every tag" },
      { ar: "رقمك مخفي بشكل افتراضي", en: "Your number is hidden by default" },
      { ar: "من غير بطارية ولا شحن", en: "No battery, no charging" },
    ],
    features: [
      {
        title: { ar: "الخصوصية أولاً", en: "Privacy first" },
        text: {
          ar: "اللي يلاقي حاجتك يبعتلك رسالة من صفحة المسح، ورقمك مش بيظهر له إلا لو انت اخترت كده.",
          en: "The finder sends you a message from the scan page, and your number is only revealed if you choose to share it.",
        },
      },
      {
        title: { ar: "رمز فريد وعشوائي", en: "Unique, random code" },
        text: {
          ar: "كل تاج ليه رمز عشوائي خاص بيه، فمفيش تاجين بنفس الرمز ومفيش حد يقدر يخمّن رمز تاج تاني.",
          en: "Every tag has its own random code, so no two tags match and nobody can guess another tag's code.",
        },
      },
      {
        title: { ar: "من غير تطبيق للي يلاقيها", en: "No app for the finder" },
        text: {
          ar: "أي كاميرا موبايل حديثة تفتح الصفحة مباشرة، فالشخص اللي لقى حاجتك مش محتاج يحمّل حاجة.",
          en: "Any modern phone camera opens the page directly, so the person who found your item does not need to install anything.",
        },
      },
      {
        title: { ar: "تركيب في ثواني", en: "Set up in seconds" },
        text: {
          ar: "علّقه في حلقة المفاتيح أو على السوستة أو الزقه، وخلاص. مفيش إعدادات معقدة ولا بطارية تخلص.",
          en: "Hang it on a key ring or zipper, and you are done. No complicated setup and no battery to run out.",
        },
      },
    ],
    steps: [
      {
        title: { ar: "ركّب التاج", en: "Attach the tag" },
        text: { ar: "علّقه على الشنطة أو المفاتيح أو أي حاجة بتخاف تضيع منك.", en: "Hang it on your bag, keys, or anything you would hate to lose." },
        image: stepImgs[0],
      },
      {
        title: { ar: "اللي يلاقيها يمسح الرمز", en: "The finder scans the code" },
        text: { ar: "بكاميرا موبايله بتفتحله صفحة بسيطة، من غير تحميل أي تطبيق.", en: "With their phone camera, a simple page opens, with no app download." },
        image: stepImgs[1],
      },
      {
        title: { ar: "توصلك رسالة", en: "You receive a message" },
        text: { ar: "بيبعتلك رسالة وانت ترد وتتفقوا على التسليم، ورقمك لسه مخفي.", en: "They send you a message, you reply and agree on the hand-over, and your number stays private." },
        image: stepImgs[2],
      },
    ],
    idealFor: [
      { ar: "مفاتيح البيت والعربية", en: "House and car keys" },
      { ar: "المحفظة", en: "Wallets" },
      { ar: "شنطة المدرسة والجامعة", en: "School and university bags" },
      { ar: "اللابتوب وشنطته", en: "Laptops and laptop bags" },
      { ar: "شنطة السفر", en: "Travel luggage" },
      { ar: "حافظة السماعات والشاحن", en: "Earbud and charger cases" },
    ],
    faq: [
      {
        q: { ar: "رقم تليفوني بيظهر للي يلاقي الحاجة؟", en: "Does the finder see my phone number?" },
        a: { ar: "لا. بشكل افتراضي بيبعتلك رسالة بس، ورقمك بيفضل مخفي إلا لو قررت تشاركه.", en: "No. By default they only send you a message and your number stays hidden unless you decide to share it." },
      },
      {
        q: { ar: "محتاج تطبيق عشان التاج يشتغل؟", en: "Do I need an app for the tag to work?" },
        a: { ar: "الشخص اللي بيلاقي الحاجة مش محتاج أي تطبيق، كاميرا الموبايل تكفي.", en: "The person who finds the item needs no app; a phone camera is enough." },
      },
      {
        q: { ar: "التاج بيحتاج بطارية أو شحن؟", en: "Does the tag need a battery or charging?" },
        a: { ar: "لا، هو رمز QR مطبوع، فمفيش بطارية تخلص.", en: "No. It is a printed QR code, so there is no battery to run out." },
      },
      {
        q: { ar: "ينفع أطلب أكتر من تاج؟", en: "Can I order more than one tag?" },
        a: { ar: "أكيد، من صفحة الطلب تقدر تطلب لحد ٢٠ تاج في الطلب الواحد.", en: "Of course. On the order page you can request up to 20 tags per order." },
      },
      {
        q: { ar: "إيه اللي بيحصل بعد ما أطلب؟", en: "What happens after I order?" },
        a: { ar: "بنسجّل طلبك وبنتواصل معاك لتأكيده، ومصاريف الشحن بتتحدد وقت التأكيد. الدفع حالياً عند الاستلام.", en: "We record your order and contact you to confirm it; shipping fees are set at confirmation. Payment is currently cash on delivery." },
      },
    ],
  },
  {
    id: "sports-gear-tag",
    slug: "sports-gear-tag",
    price: 180,
    currency: "EGP",
    category: { ar: "تاجات QR", en: "QR Tags" },
    image: "/images/sports-gear-tag.svg",
    imageAlt: {
      ar: "شنطة جيم رياضية عليها تاج QR متعلّق وعلامة موقع",
      en: "A gym bag with a hanging QR tag and a location pin",
    },
    name: { ar: "تاج المعدات الرياضية", en: "Sports Gear Tag" },
    short: {
      ar: "تاج QR عملي لشنط الجيم والملعب ومعدات التمرين، عشان حاجتك ترجعلك لو اتنسيت في أي مكان.",
      en: "A practical QR tag for gym and sports bags and training gear, so your things find their way back if you leave them behind.",
    },
    description: [
      {
        ar: "شنطة الجيم أو الملعب أول حاجة بتتنسى في أوضة الغيار أو الكافيه بعد التمرين. تاج المعدات الرياضية بيخلي أي حد يلاقيها يقدر يوصلك بسهولة.",
        en: "A gym or sports bag is the first thing to be forgotten in the changing room or the café after training. The Sports Gear Tag lets anyone who finds it reach you easily.",
      },
      {
        ar: "بنفس فكرة «لاقيتها»: رمز QR فريد ورسالة من غير ما رقمك يظهر، لكن مخصص لاستخدام الرياضة: شنط الجيم، شنط الكورة والتدريب، وحقائب الأكاديميات ومعدات التمرين الشخصية.",
        en: "It follows the La2etha idea: a unique QR code and a message without exposing your number, but made for sport: gym bags, football and training bags, academy kit bags, and personal training equipment.",
      },
      {
        ar: "ولو انت مدرب أو بتدير أكاديمية أو فريق، تقدر تطلب لحد ٢٠ تاج في الطلب الواحد وكل لاعب يبقى ليه تاجه الخاص.",
        en: "If you are a coach or run an academy or team, you can order up to 20 tags per order so every player gets their own.",
      },
    ],
    highlights: [
      { ar: "مناسب لشنط الجيم والملعب", en: "Made for gym and sports bags" },
      { ar: "تاج لكل لاعب في الفريق", en: "One tag for every team member" },
      { ar: "رسائل من غير ما رقمك يظهر", en: "Messages without exposing your number" },
    ],
    features: [
      {
        title: { ar: "لكل رياضي تاجه", en: "One tag per athlete" },
        text: {
          ar: "كل تاج له رمز فريد، فكل لاعب أو مشترك ليه حاجته المعروفة والمنفصلة.",
          en: "Each tag has its own unique code, so every player or member has their own identifiable kit.",
        },
      },
      {
        title: { ar: "بيتعلّق في أي مكان", en: "Hangs anywhere" },
        text: {
          ar: "علّقه على السوستة أو مقبض الشنطة أو حلقة معدات التمرين من غير ما يعطّلك.",
          en: "Hang it on a zipper, a bag handle, or a loop of your training gear without getting in the way.",
        },
      },
      {
        title: { ar: "الخصوصية محفوظة", en: "Your privacy stays safe" },
        text: {
          ar: "اللي يلاقي الشنطة يبعتلك رسالة فقط، ومفيش رقم بيتعرض للغريب بشكل افتراضي.",
          en: "The finder only sends you a message; no number is shown to a stranger by default.",
        },
      },
      {
        title: { ar: "للأكاديميات والفرق", en: "For academies and teams" },
        text: {
          ar: "اطلب كمية للفريق كله في طلب واحد، ووزّع تاج لكل لاعب أو مدرب.",
          en: "Order for the whole team in one go and hand out a tag to each player or coach.",
        },
      },
    ],
    steps: [
      {
        title: { ar: "علّق التاج على الشنطة", en: "Hang the tag on the bag" },
        text: { ar: "على السوستة أو المقبض، وخليه ظاهر للي يلاقيها.", en: "On the zipper or handle, visible to whoever finds it." },
        image: stepImgs[0],
      },
      {
        title: { ar: "اللي يلاقيها يمسح الرمز", en: "The finder scans the code" },
        text: { ar: "كاميرا الموبايل بتفتح صفحة الرسالة على طول.", en: "The phone camera opens the message page straight away." },
        image: stepImgs[1],
      },
      {
        title: { ar: "ترجعلك شنطتك", en: "Your bag finds its way back" },
        text: { ar: "بتوصلك رسالة وتتفقوا على الاستلام، من غير ما رقمك يظهر.", en: "You get a message and agree on pick-up, without your number showing." },
        image: stepImgs[2],
      },
    ],
    idealFor: [
      { ar: "شنط الجيم", en: "Gym bags" },
      { ar: "شنط الكورة والتدريب", en: "Football and training bags" },
      { ar: "أكاديميات الأطفال", en: "Kids' academies" },
      { ar: "النوادي والفرق", en: "Clubs and teams" },
      { ar: "الخوذة والمضرب وأدوات الرياضة", en: "Helmets, rackets, and sports kit" },
    ],
    faq: [
      {
        q: { ar: "إيه الفرق بينه وبين تاج لاقيتها؟", en: "How is it different from the La2etha Tag?" },
        a: { ar: "نفس تقنية QR ونفس الخصوصية، لكن ده مخصص لاستخدام الرياضة ومعداتها وليه سعر مختلف.", en: "Same QR technology and privacy, but it is designed for sports use and gear, and is priced differently." },
      },
      {
        q: { ar: "ينفع أطلب لفريق كامل؟", en: "Can I order for a whole team?" },
        a: { ar: "أيوه، لحد ٢٠ تاج في الطلب الواحد.", en: "Yes, up to 20 tags per order." },
      },
      {
        q: { ar: "رقم تليفوني بيظهر للغريب؟", en: "Is my number shown to strangers?" },
        a: { ar: "لا، بشكل افتراضي بيوصلك رسالة بس.", en: "No. By default you only receive a message." },
      },
    ],
  },
  {
    id: "google-review-stand",
    slug: "google-review-stand",
    price: 350,
    currency: "EGP",
    category: { ar: "للبيزنس", en: "Business" },
    image: "/images/google-review-stand.svg",
    imageAlt: {
      ar: "ستاند أكريليك للتقييمات عليه خمس نجوم ورمز QR على كاونتر محل",
      en: "An acrylic review stand with five stars and a QR code on a shop counter",
    },
    name: { ar: "ستاند تقييمات جوجل", en: "Google Review Stand" },
    short: {
      ar: "ستاند بسيط على الكاشير أو الطاولة؛ العميل يمسح الرمز ويكتب تقييمه على صفحة محلك في ثواني.",
      en: "A simple stand for your counter or table; customers scan the code and review your business in seconds.",
    },
    description: [
      {
        ar: "التقييمات على جوجل بتفرق كتير في اختيار الناس لمكان ياكلوا فيه أو يشتروا منه. والمشكلة إن أغلب العملاء الراضيين مش بيفتكروا يكتبوا تقييم.",
        en: "Google reviews strongly influence where people choose to eat or shop. The problem is that most happy customers simply forget to leave one.",
      },
      {
        ar: "الستاند ده بيسهّل الخطوة: رمز QR واضح على الكاشير أو الطاولة، والعميل بيمسحه بكاميرا موبايله ويوصل مباشرة لصفحة التقييم الخاصة بمحلك.",
        en: "This stand makes it easy: a clear QR code at the counter or on the table that customers scan with their phone to land directly on your business's review page.",
      },
      {
        ar: "مناسب للمطاعم والكافيهات والصيدليات والعيادات والصالونات وأي نشاط بيتعامل مع عملاء وجهاً لوجه. بعد تسجيل الطلب فريقنا هيتواصل معاك لتأكيد رابط صفحة التقييم قبل التجهيز.",
        en: "Great for restaurants, cafés, pharmacies, clinics, salons, and any business that serves customers face to face. After you order, our team will contact you to confirm your review-page link before preparing the stand.",
      },
    ],
    highlights: [
      { ar: "رمز QR مباشر لصفحة تقييم محلك", en: "QR straight to your review page" },
      { ar: "يتحط على الكاشير أو الطاولة", en: "Sits on the counter or table" },
      { ar: "العميل مش محتاج تطبيق", en: "No app needed for customers" },
    ],
    features: [
      {
        title: { ar: "مسح واحد وخلاص", en: "One scan is all it takes" },
        text: {
          ar: "العميل يفتح الكاميرا ويمسح، فيوصل لصفحة التقييم من غير ما يدوّر عن اسم محلك.",
          en: "The customer opens the camera and scans, landing on the review page without searching for your business name.",
        },
      },
      {
        title: { ar: "شكل نضيف يناسب أي محل", en: "A clean look for any shop" },
        text: {
          ar: "تصميم هادي بنجوم واضحة ورمز QR كبير، مش بيزحم الكاونتر ولا بيتعارض مع ديكور المكان.",
          en: "A calm design with clear stars and a large QR code that does not crowd the counter or clash with your decor.",
        },
      },
      {
        title: { ar: "مخصص لنشاطك", en: "Set up for your business" },
        text: {
          ar: "الرمز بيتظبط على رابط صفحة التقييم الخاصة بيك، بعد ما نأكده معاك وقت تأكيد الطلب.",
          en: "The code is set to your own review-page link, which we confirm with you when confirming the order.",
        },
      },
      {
        title: { ar: "للنشاط اللي بيقابل عملاء", en: "For customer-facing businesses" },
        text: {
          ar: "مثالي لأي مكان العميل بيدفع أو بيستلم فيه وبيبقى موبايله في إيده.",
          en: "Ideal anywhere customers pay or collect their order with their phone already in hand.",
        },
      },
    ],
    steps: [
      {
        title: { ar: "حطّه في مكان واضح", en: "Place it where it is seen" },
        text: { ar: "على الكاشير أو الطاولة أو عند الاستقبال.", en: "At the till, on the table, or at reception." },
        image: stepImgs[0],
      },
      {
        title: { ar: "العميل يمسح الرمز", en: "The customer scans the code" },
        text: { ar: "بكاميرا موبايله بيفتح صفحة التقييم مباشرة.", en: "With their phone camera, the review page opens directly." },
        image: stepImgs[1],
      },
      {
        title: { ar: "يكتب تقييمه", en: "They write a review" },
        text: { ar: "في ثواني يقيّم تجربته ويوصل تقييمه لمحلك.", en: "In seconds they rate their experience and it appears for your business." },
        image: stepImgs[2],
      },
    ],
    idealFor: [
      { ar: "المطاعم والكافيهات", en: "Restaurants and cafés" },
      { ar: "الصيدليات والعيادات", en: "Pharmacies and clinics" },
      { ar: "الصالونات ومراكز التجميل", en: "Salons and beauty centres" },
      { ar: "المحلات والمعارض", en: "Shops and showrooms" },
      { ar: "الفنادق والاستقبال", en: "Hotels and reception desks" },
    ],
    faq: [
      {
        q: { ar: "لازم يكون عندي صفحة على جوجل؟", en: "Do I need a Google business listing?" },
        a: { ar: "أيوه، لازم يكون لنشاطك صفحة على جوجل (Google Business Profile) عشان الرمز يوصّل العميل لصفحة التقييم.", en: "Yes. Your business needs a Google Business Profile so the code can lead customers to its review page." },
      },
      {
        q: { ar: "بتضمنوا زيادة عدد التقييمات؟", en: "Do you guarantee more reviews?" },
        a: { ar: "لا، الستاند بيسهّل على العميل يقيّم، لكن عدد التقييمات بيعتمد على تجربة عملائك وعلى مكان الستاند.", en: "No. The stand makes it easier to review, but the number of reviews depends on your customers' experience and where you place it." },
      },
      {
        q: { ar: "إيه اللي بيحصل بعد الطلب؟", en: "What happens after I order?" },
        a: { ar: "هنتواصل معاك لتأكيد الطلب ورابط صفحة التقييم قبل التجهيز، ومصاريف الشحن بتتحدد وقتها.", en: "We contact you to confirm the order and your review-page link before preparing it; shipping fees are set at that point." },
      },
    ],
  },
];

export const findProduct = (slug?: string | null) => products.find((p) => p.slug === slug);
