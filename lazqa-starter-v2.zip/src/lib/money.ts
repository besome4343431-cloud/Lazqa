export const formatEGP = (amount: number, locale = "en-EG") =>
  new Intl.NumberFormat(locale, { style: "currency", currency: "EGP", maximumFractionDigits: 0 }).format(amount);