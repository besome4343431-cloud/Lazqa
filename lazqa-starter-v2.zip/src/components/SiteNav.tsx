import Link from "next/link";
import Image from "next/image";
import { tr, type Lang } from "@/lib/i18n";

export default function SiteNav({ lang, path, full = true }: { lang: Lang; path: string; full?: boolean }) {
  const t = tr(lang);
  const other: Lang = lang === "ar" ? "en" : "ar";
  return (
    <nav className="nav">
      <Link className="logo" href="/">
        <Image src="/images/logo.svg" alt="" width={34} height={34} unoptimized priority />
        <b>
          Lazqa<span>.</span>
        </b>
      </Link>
      <div className="navlinks">
        {full ? (
          <>
            <Link href="/#products">{t("navProducts")}</Link>
            <Link href="/la2etha">{t("navLa2etha")}</Link>
            <Link href="/account">{t("navAccount")}</Link>
            <Link href="/admin">{t("navAdmin")}</Link>
          </>
        ) : (
          <Link href="/">{t("backToStore")}</Link>
        )}
        <a className="langbtn" href={`/api/lang?set=${other}&next=${encodeURIComponent(path)}`} lang={other} hrefLang={other}>
          {lang === "ar" ? "English" : "العربية"}
        </a>
      </div>
    </nav>
  );
}
