import Image from "next/image";
import { tr, type Lang } from "@/lib/i18n";
import type { Product } from "@/lib/products";

export default function ProductSections({ product, lang }: { product: Product; lang: Lang }) {
  const t = tr(lang);
  return (
    <>
      <section>
        <h2 className="subhead">{t("pdFeatures")}</h2>
        <div className="feat-grid">
          {product.features.map((f, i) => (
            <div className="feat" key={i}>
              <h3>{f.title[lang]}</h3>
              <p>{f.text[lang]}</p>
            </div>
          ))}
        </div>
      </section>

      <section>
        <h2 className="subhead">{t("pdHow")}</h2>
        <div className="steps">
          {product.steps.map((s, i) => (
            <div className="step" key={i}>
              <Image src={s.image} alt="" width={240} height={240} unoptimized />
              <div className="num">
                {t("step")} {lang === "ar" ? ["١", "٢", "٣"][i] : i + 1}
              </div>
              <h3>{s.title[lang]}</h3>
              <p>{s.text[lang]}</p>
            </div>
          ))}
        </div>
      </section>

      <section>
        <h2 className="subhead">{t("pdIdeal")}</h2>
        <div className="chips">
          {product.idealFor.map((c, i) => (
            <span className="chip" key={i}>
              {c[lang]}
            </span>
          ))}
        </div>
      </section>

      <section>
        <h2 className="subhead">{t("pdFaq")}</h2>
        <div className="faq">
          {product.faq.map((f, i) => (
            <details key={i}>
              <summary>{f.q[lang]}</summary>
              <p>{f.a[lang]}</p>
            </details>
          ))}
        </div>
      </section>
    </>
  );
}
