import { tr, type Lang } from "@/lib/i18n";

export default function SiteFooter({ lang }: { lang: Lang }) {
  return (
    <footer className="footer">
      © {new Date().getFullYear()} {tr(lang)("footer")}
    </footer>
  );
}
