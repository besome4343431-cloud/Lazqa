import Image from "next/image";

// Local SVGs are served as-is; remote images (Supabase Storage) go through next/image optimisation.
export default function ProductImage({
  src,
  alt,
  priority = false,
  sizes = "(max-width: 760px) 100vw, 360px",
  className = "product-img",
}: {
  src?: string | null;
  alt: string;
  priority?: boolean;
  sizes?: string;
  className?: string;
}) {
  const url = src || "/images/placeholder.svg";
  return (
    <Image
      src={url}
      alt={alt}
      width={800}
      height={600}
      sizes={sizes}
      priority={priority}
      className={className}
      unoptimized={url.endsWith(".svg")}
    />
  );
}
